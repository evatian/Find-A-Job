<?php
// DB Params
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "tshtsh1234");
define("DB_NAME", "joblister");

define("SITE_TITLE", "JobLister");