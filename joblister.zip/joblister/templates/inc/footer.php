			<footer class="footer">
        <p>&copy; 2017 JobLister, Inc.</p>
      </footer>

    </div> <!-- /container -->
		</body>
</html>